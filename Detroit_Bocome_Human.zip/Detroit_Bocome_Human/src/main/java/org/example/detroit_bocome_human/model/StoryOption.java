package org.example.detroit_bocome_human.model;

import jakarta.persistence.*;
import lombok.Data;

/**
 * StoryOption (边)
 * 作用：连接两个剧情节点，并处理“条件审核”和“数值结算”。
 */
@Entity
@Data
@Table(name = "story_option")
public class StoryOption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- 1. 基本连接信息 ---

    // 这条边属于哪个出发节点？(外键)
    private Long fromNodeId;

    // 按钮上显示的文字 (例如 "【拔枪】射击")
    private String buttonText;

    // 点击后去哪个节点？(目标)
    private Long targetNodeId;

    // --- 2. 审核逻辑 (Condition / Lock) ---
    // 你的疑问：审核放在哪？答案：规则写在这里，判断交给 Controller/JSP。

    // 需要检查的属性类型 (例如 "TRUST", "HAS_GUN", "HP")
    // 如果为 null，代表无门槛
    private String conditionType;

    // 需要达到的数值 (例如 80, 1)
    private Integer conditionValue;

    // --- 3. 结算逻辑 (Effect / Reward) ---
    // 你的需求：边要改数据。就在这里定义！

    // 造成的属性变化类型 (例如 "TRUST", "HP")
    private String effectType;

    // 变化的数值 (例如 +10, -20)
    private Integer effectValue;
}