package org.example.detroit_bocome_human.controller;

import org.example.detroit_bocome_human.model.User;
import org.example.detroit_bocome_human.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // 1. 注入发送邮件的工具 (Spring Boot 自动配置)
    @Autowired
    private JavaMailSender mailSender;

    // 【重要】发件人邮箱：必须和你 application.yml 里填的一模一样！
    private final String FROM_EMAIL = "wanghuian2003@qq.com";

    // 2. 验证码缓存中心 (邮箱 -> 验证码)
    // 用来暂时记录谁请求了哪个验证码
    private static Map<String, String> codeCache = new ConcurrentHashMap<>();

    // --- 新功能 A：发送验证码 (AJAX 接口) ---
    @ResponseBody // 这个注解表示返回纯文本，不跳转页面
    @PostMapping("/api/sendCode")
    public String sendCode(@RequestParam String phone) {
        // 注意：这里的参数虽然叫 phone，但前端填的其实是邮箱地址

        // 1. 生成 4 位随机验证码
        String code = String.valueOf((int)((Math.random() * 9 + 1) * 1000));

        // 2. 存入缓存 (这就相当于把邮箱当做 ID)
        codeCache.put(phone, code);

        try {
            // 3. 构建邮件内容
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(FROM_EMAIL);   // 谁发的
            message.setTo(phone);          // 发给谁
            message.setSubject("【CyberLife】底特律系统身份验证"); // 邮件标题
            message.setText("亲爱的调查员：\n\n您正在尝试登录底特律模组系统。\n您的验证码是：" + code + "\n\n(有效期5分钟，请勿泄露给仿生人)"); // 邮件正文

            // 4. 发送！
            mailSender.send(message);
            System.out.println("✅ 邮件已成功发送给：" + phone);
            return "success"; // 告诉前端发送成功
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ 邮件发送失败：" + e.getMessage());
            return "error"; // 告诉前端发送失败
        }
    }

    // --- 新功能 B：邮箱验证码登录 ---
    @PostMapping("/user/loginByPhone")
    public String loginByPhone(@RequestParam String phone,
                               @RequestParam String code,
                               HttpSession session,
                               Model model) {
        // 1. 检查验证码对不对
        String correctCode = codeCache.get(phone);
        if (correctCode == null || !correctCode.equals(code)) {
            model.addAttribute("error", "验证码错误或已过期！");
            return "login"; // 验证失败，留在登录页
        }

        // 2. 验证码正确！去数据库查找用户
        User user = userRepository.findByUsername(phone); // 把邮箱当做用户名来查

        if (user == null) {
            // 3. 如果是新用户，自动注册！
            user = new User();
            user.setUsername(phone); // 用户名就设为邮箱
            user.setPassword("123456"); // 给个默认密码
            user.setPhone(phone);    // 把邮箱存进 phone 字段
            userRepository.save(user);
        }

        // 4. 登录成功，发放 Session 通行证
        session.setAttribute("user", user);

        // 5. 清除验证码 (防止重复使用)
        codeCache.remove(phone);

        return "redirect:/game/menu"; // 进入游戏
    }

    // --- 原有功能 C：展示注册页面 ---
    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    // --- 原有功能 D：账号密码注册 ---
    @PostMapping("/user/register")
    public String doRegister(@RequestParam String username,
                             @RequestParam String password,
                             Model model) {
        if (userRepository.findByUsername(username) != null) {
            model.addAttribute("error", "用户名已存在！");
            return "register";
        }
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(password);
        userRepository.save(newUser);
        return "redirect:/login";
    }

    // --- 原有功能 E：展示登录页面 ---
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    // --- 原有功能 F：账号密码登录 ---
    @PostMapping("/user/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          HttpSession session,
                          Model model) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            session.setAttribute("user", user);
            return "redirect:/game/menu";
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "login";
        }
    }
    // ==========================================
    // 🏠 首页重定向 (Root Redirect)
    // 作用：访问域名根目录 (localhost:8080) 时，自动跳到 /login
    // ==========================================
    @GetMapping("/")
    public String root() {
        return "redirect:/login";
    }
}