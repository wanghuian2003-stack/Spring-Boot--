package org.example.detroit_bocome_human.repository;

import org.example.detroit_bocome_human.model.GameArchive;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 存档仓库
 * 作用：专门负责去数据库里查 GameArchive 表
 */
@Repository
public interface GameArchiveRepository extends JpaRepository<GameArchive, Long> {

    // 🔍 核心功能：根据 UserID 找他的存档
    // 相当于 SQL: SELECT * FROM game_archive WHERE user_id = ?
    GameArchive findByUserId(Long userId);
}