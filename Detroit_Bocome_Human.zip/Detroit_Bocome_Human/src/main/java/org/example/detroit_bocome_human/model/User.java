package org.example.detroit_bocome_human.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "game_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String username;
    private String password;
    private String phone;

    // ❌ 删掉 currentProgress, trustValue, hp 等字段
    // 这里的任务就是单纯的登录
}