package org.example.detroit_bocome_human.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.Date;

/**
 * 终极存档类 (GameArchive)
 * 包含：核心持久化属性 + 章节临时变量
 */
@Entity
@Data
@Table(name = "game_archive")
public class GameArchive {

    // ==========================================
    // 💾 0. 基础系统信息
    // ==========================================
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long archiveId;

    private Long userId;        // 玩家ID
    private String archiveName; // 存档名
    private Date saveTime;      // 时间
    private Long currentNodeId; // 当前在哪一页

    // 🌍 全局舆论 (Public Opinion)
    // 范围：0(被憎恨) < 40(怀疑) < 60(同情) < 80(支持)
    private Integer publicOpinion = 40;

    // ==========================================
    // 🟦 1. 康纳线 (Connor) - 追捕者
    // ==========================================

    // 🧠 软体不稳定度 (Software Instability)
    private Integer connorInstability = 0;

    // 👮 汉克关系 (Hank)
    private Integer relationHank = 30;

    // 👁️ 阿曼达信任 (Amanda)
    private Integer trustAmanda = 80;

    // ♻️ [新增] 康纳专用临时变量
    // 用途：当前案件线索数量 / 审讯压力值 / 追逐战QTE成功数
    // 注意：切章节时建议归零
    private Integer connorTemp = 0;

    // ==========================================
    // 🟧 2. 马库斯线 (Markus) - 革命者
    // ==========================================

    // ✊ 耶利哥声望
    private Integer reputationJericho = 0;

    // ❤️ 诺斯 (North)
    private Integer relationNorth = 50;

    // 🕊️ 乔西/乔许 (Josh)
    private Integer relationJosh = 50;

    // 🛡️ 西蒙 (Simon)
    private Integer relationSimon = 50;

    // ♻️ [新增] 马库斯专用临时变量
    // 用途：潜行关卡躲避次数 / 演讲煽动值 / 搜集零件数量
    private Integer markusTemp = 0;

    // ==========================================
    // 🟥 3. 卡拉线 (Kara) - 守护者
    // ==========================================

    // 👧 爱丽丝 (Alice)
    private Integer relationAlice = 40;

    // 🛡️ 路德 (Luther)
    private Integer relationLuther = 0; // 初始未遇到

    // ♻️ [新增] 卡拉专用临时变量
    // 用途：打扫卫生进度 / 偷窃紧张度 / 哄爱丽丝开心的次数
    private Integer karaTemp = 0;

    // ==========================================
    // 🛠️ 构造函数 (初始化)
    // ==========================================
    public GameArchive() {
        this.saveTime = new Date();

        // --- 初始数值设定 ---
        // 康纳
        this.connorInstability = 0;
        this.relationHank = 20;
        this.trustAmanda = 80;
        this.connorTemp = 0; // 初始化临时变量

        // 马库斯
        this.publicOpinion = 40;
        this.reputationJericho = 0;
        this.relationNorth = 50;
        this.relationJosh = 50;
        this.relationSimon = 50;
        this.markusTemp = 0; // 初始化临时变量

        // 卡拉
        this.relationAlice = 30;
        this.relationLuther = 0;
        this.karaTemp = 0; // 初始化临时变量
    }
}