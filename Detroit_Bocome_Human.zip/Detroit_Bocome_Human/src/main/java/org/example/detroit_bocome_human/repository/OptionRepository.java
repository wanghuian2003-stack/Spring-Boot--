package org.example.detroit_bocome_human.repository;

import org.example.detroit_bocome_human.model.StoryOption;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OptionRepository extends JpaRepository<StoryOption, Long> {

    // 🔍 核心指令：根据 sourceNodeId 查找所有属于它的选项
    // 对应 SQL: SELECT * FROM story_option WHERE from_node_id = ?
    List<StoryOption> findByFromNodeId(Long fromNodeId);
}