package org.example.detroit_bocome_human.repository;

import org.example.detroit_bocome_human.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // 这一行代码的神奇之处：
    // 你只要写出名字，SpringBoot 就会自动帮你生成 SQL: select * from game_user where username = ?
    User findByUsername(String username);
}