package org.example.detroit_bocome_human.repository;

import org.example.detroit_bocome_human.model.StoryNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// 👇 把 String 改成 Long，红线瞬间消失，而且数据库读写顺畅！
@Repository
public interface NodeRepository extends JpaRepository<StoryNode, Long> {

}