package org.example.detroit_bocome_human.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Entity
@Data
@Table(name = "story_node")
public class StoryNode {

    @Id
    private Long nodeId;

    private String title;
    private String sceneInfo;
    private String speaker;

    // 🔥 新增：当前视角主角
    // 取值建议： "CONNOR" (康纳), "MARKUS" (马库斯), "KARA" (卡拉)
    // 前端会根据这个值，把 UI 变成 蓝色(康纳)、橙色(马库斯) 或 灰色(卡拉)
    private String mainCharacter;

    @Column(length = 5000)
    private String content;

    private String bgImage;
    private String video;

    @Transient
    private List<StoryOption> options;
}