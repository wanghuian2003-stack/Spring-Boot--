package org.example.detroit_bocome_human;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DetroitBocomeHumanApplication {

    public static void main(String[] args) {
        SpringApplication.run(DetroitBocomeHumanApplication.class, args);
    }

}
