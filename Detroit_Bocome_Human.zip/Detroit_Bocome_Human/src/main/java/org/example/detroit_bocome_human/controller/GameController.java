package org.example.detroit_bocome_human.controller;

import jakarta.servlet.http.HttpSession;
import org.example.detroit_bocome_human.model.*;
import org.example.detroit_bocome_human.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/game")
public class GameController {

    @Autowired
    private NodeRepository nodeRepository;

    @Autowired
    private OptionRepository optionRepository;

    @Autowired
    private GameArchiveRepository archiveRepository;

    @GetMapping("/menu")
    public String showMenu(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        GameArchive archive = archiveRepository.findByUserId(user.getId());
        if (archive != null) {
            model.addAttribute("hasArchive", true);
            model.addAttribute("lastSaveTime", archive.getSaveTime());
        } else {
            model.addAttribute("hasArchive", false);
        }
        return "menu";
    }

    @GetMapping("/new_game")
    public String newGame(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        GameArchive archive = archiveRepository.findByUserId(user.getId());
        if (archive == null) {
            archive = new GameArchive();
            archive.setUserId(user.getId());
            archive.setArchiveName("Default Save");
        }

        // ==========================================
        // 🔧 关键修改：初始化数值与入口
        // ==========================================

        // 1. 设置正确的剧情入口 (序章：人质 ID = 1001)
        archive.setCurrentNodeId(1001L);
        archive.setSaveTime(new Date());

        // 2. 初始化：康纳 (Connor)
        archive.setConnorInstability(0); // 软体不稳定度
        archive.setConnorTemp(0);        // 临时变量 (线索收集/开枪标记)
        archive.setTrustAmanda(50);      // 阿曼达信任值 (初始给个中等值)
        archive.setRelationHank(20);     // 汉克好感度 (初始稍微有点基础)

        // 3. 初始化：马库斯 (Markus) & 世界观
        archive.setPublicOpinion(20);    // 舆论 (初始稍微正面一点)
        archive.setReputationJericho(0); // 耶利哥声望
        archive.setMarkusTemp(0);        // 临时变量 (暴力/和平倾向)
        archive.setRelationNorth(0);     // 诺丝好感
        archive.setRelationJosh(0);      // 乔许好感
        archive.setRelationSimon(0);     // 赛门好感

        // 4. 初始化：卡拉 (Kara)
        archive.setKaraTemp(0);          // 临时变量 (是否完美隐藏等)
        archive.setRelationAlice(10);    // 爱丽丝好感 (初始有一点)
        archive.setRelationLuther(0);    // 路德好感

        archiveRepository.save(archive);

        // 跳转到 1001
        return "redirect:/game/" + archive.getCurrentNodeId();
    }

    @GetMapping("/continue")
    public String continueGame(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        GameArchive archive = archiveRepository.findByUserId(user.getId());
        if (archive == null) return "redirect:/game/new_game";

        return "redirect:/game/" + archive.getCurrentNodeId();
    }

    @GetMapping("/{nodeId}")
    public String gamePage(@PathVariable Long nodeId, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        GameArchive archive = archiveRepository.findByUserId(user.getId());
        if (archive == null) return "redirect:/game/new_game";

        StoryNode node = nodeRepository.findById(nodeId).orElse(null);
        // 如果找不到节点，回菜单（防止报错）
        if (node == null) return "redirect:/game/menu";

        List<StoryOption> options = optionRepository.findByFromNodeId(nodeId);
        node.setOptions(options);

        model.addAttribute("node", node);
        model.addAttribute("user", archive); // 前端可以通过 ${user.relationHank} 访问数值

        // 自动保存进度
        if (!nodeId.equals(archive.getCurrentNodeId())) {
            archive.setCurrentNodeId(nodeId);
            archive.setSaveTime(new Date());
            archiveRepository.save(archive);
        }
        return "game";
    }

    @GetMapping("/choose/{optionId}")
    public String makeChoice(@PathVariable Long optionId, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        // 1. 查找选项
        StoryOption option = optionRepository.findById(optionId).orElse(null);
        if (option == null) return "redirect:/game/menu";

        // 2. 获取存档
        GameArchive archive = archiveRepository.findByUserId(user.getId());

        // 3. 检查条件 (Lock) - 如果条件不满足，留在当前页面
        if (isLocked(archive, option)) {
            return "redirect:/game/" + option.getFromNodeId();
        }

        // 4. 应用数值变化 (Effect)
        applyEffect(archive, option);

        // 5. 保存并跳转
        archiveRepository.save(archive);
        return "redirect:/game/" + option.getTargetNodeId();
    }

    // ==========================================
    // 🧠 核心逻辑：条件检查 (补全了所有角色)
    // ==========================================
    private boolean isLocked(GameArchive archive, StoryOption option) {
        String type = option.getConditionType();
        Integer val = option.getConditionValue();

        if (type == null || val == null) return false; // 无条件，直接通过

        // 只要 存档数值 < 需求数值，就锁定 (return true)
        switch (type) {
            // --- 康纳线 ---
            case "HANK":        return archive.getRelationHank() < val;
            case "INSTABILITY": return archive.getConnorInstability() < val;
            case "CONNOR_TEMP": return archive.getConnorTemp() < val;

            // --- 马库斯线 ---
            case "PUBLIC":      return archive.getPublicOpinion() < val;
            case "MARKUS_TEMP":
                // 特殊处理：MarkusTemp 正数代表和平，负数代表暴力
                // 这里简化逻辑：如果是正数要求，必须大于等于；如果是负数要求，必须小于等于（这里暂按大于处理通用逻辑）
                return archive.getMarkusTemp() < val;

            // --- 卡拉线 ---
            case "ALICE":       return archive.getRelationAlice() < val;
            case "KARA_TEMP":   return archive.getKaraTemp() < val;

            default: return false;
        }
    }

    // ==========================================
    // ⚡ 核心逻辑：数值应用 (补全了所有角色)
    // ==========================================
    private void applyEffect(GameArchive archive, StoryOption option) {
        String type = option.getEffectType();
        Integer val = option.getEffectValue();

        if (type == null || val == null) return;

        // 这里支持加减法 (val 可以是负数)
        switch (type) {
            // --- 康纳 ---
            case "HANK":            archive.setRelationHank(archive.getRelationHank() + val); break;
            case "INSTABILITY":     archive.setConnorInstability(archive.getConnorInstability() + val); break;
            case "CONNOR_TEMP":     // 既可以做加法，也可以做覆盖，数据库里有些地方是加1(线索)，有些是设为100(标记)
            case "CONNOR_TEMP_ADD": archive.setConnorTemp(archive.getConnorTemp() + val); break;

            // --- 马库斯 ---
            case "PUBLIC":          archive.setPublicOpinion(archive.getPublicOpinion() + val); break;
            case "JERICHO":         archive.setReputationJericho(archive.getReputationJericho() + val); break;
            case "MARKUS_TEMP":     archive.setMarkusTemp(archive.getMarkusTemp() + val); break;
            case "RELATION_NORTH":  archive.setRelationNorth(archive.getRelationNorth() + val); break;
            case "RELATION_JOSH":   archive.setRelationJosh(archive.getRelationJosh() + val); break;
            case "RELATION_SIMON":  archive.setRelationSimon(archive.getRelationSimon() + val); break;

            // --- 卡拉 ---
            case "ALICE":           archive.setRelationAlice(archive.getRelationAlice() + val); break;
            case "LUTHER":          archive.setRelationLuther(archive.getRelationLuther() + val); break;
            case "KARA_TEMP":       archive.setKaraTemp(archive.getKaraTemp() + val); break;
        }
    }
}